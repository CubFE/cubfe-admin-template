<template>
  <!--begin::System Layout-->
  <div class="flex flex-col h-full w-full">
    <router-view></router-view>
  </div>
  <!--end::System Layout-->
</template>

<script lang="ts">
</script>
