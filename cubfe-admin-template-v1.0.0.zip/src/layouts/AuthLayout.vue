<template>
    <!--begin::Auth Layout-->
    <div class="flex h-screen w-full">
      <router-view></router-view>
    </div>
    <!--end::Auth Layout-->
</template>
  