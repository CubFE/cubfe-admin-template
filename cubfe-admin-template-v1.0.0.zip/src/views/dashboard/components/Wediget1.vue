<template>
    <div class="relative bg-white shadow-sm rounded-lg p-4 dark:bg-dark">
        <h3 class="text-md text-gray-600 font-medium mb-2">Total transaction amount</h3>
        <p class="text-gray-600 text-3xl font-semibold dark:text-white">$ 38,123.00</p>
        <div class="flex mt-4 text-green-600 text-sm">
            + 6.4% <ArrowTrendingUpIcon class="w-4 ml-2"/>
            <span class="ml-2 text-gray-400">since last month</span>
        </div>
        <div class="absolute right-4 top-4 p-1 rounded-full bg-green-50"><CurrencyDollarIcon class="w-6 stroke-green-600"/></div>
    </div>
</template>
