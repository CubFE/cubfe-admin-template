<template>
    <h2>ECommerce</h2>
</template>
