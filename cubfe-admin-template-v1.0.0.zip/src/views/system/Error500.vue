<template>
    <div>
        <h1>500</h1>
        <p>服务器错误</p>
    </div>
</template>
