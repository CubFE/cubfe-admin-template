<template>
    <H2>Charts</H2>
</template>
