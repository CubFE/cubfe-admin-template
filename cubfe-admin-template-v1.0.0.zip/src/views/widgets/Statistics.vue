<template>
    <H2>Statistics</H2>
</template>
