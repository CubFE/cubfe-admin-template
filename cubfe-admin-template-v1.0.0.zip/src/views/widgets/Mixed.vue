<template>
    <H2>Mixed</H2>
</template>
