<template>
    <H2>Feeds</H2>
</template>
