/// <reference types="vite/client" />
declare module '@headlessui/vue';
declare module '@heroicons/vue/24/outline';
declare module 'vue';
